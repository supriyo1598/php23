<?php

include("conn.php");

if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $age=$_POST['age'];
    $email=$_POST['email'];

    if(empty($name) || empty($age) || empty($email))
    {
        echo "Some Fields are empty";
    }
    else
    {
        $sql="insert into users (name,age,email) values('$name',$age,'$email')";
        mysqli_query($conn,$sql);

        echo "Insertion Successful";
        echo "<br><a href='index.php'>Goto Home Page</a>";
    }

}