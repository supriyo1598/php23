<?php
include("conn.php");
$sql="Select * from users";
$result=mysqli_query($conn,$sql);
print_r($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php
            while($res=mysqli_fetch_assoc($result))
            {
            ?>
            <tr>

            <?php
                echo "<td>".$res['id']."</td>";
                echo "<td>".$res['name']."</td>";
                echo "<td>".$res['age']."</td>";
                echo "<td>".$res['email']."</td>";
                echo "<td><a href=\"delete.php?id=$res[id]\">Delete</a>/Update</td>";
                
            }
            ?>
            </tr>

        ?>
    </table>
</body>
</html>