<?php
include("conn.php");

$id=$_GET['id'];
echo $id;
$sql="Delete from users where id=$id";
mysqli_query($conn,$sql);

header("Location:index.php");


?>